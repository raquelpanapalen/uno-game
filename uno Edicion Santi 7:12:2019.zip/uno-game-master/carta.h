#ifndef CARTA_H
#define CARTA_H

typedef struct
{
   int color;
   int fig;
}tcarta;

void mostrar_carta(tcarta c);

#endif
