#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "carta.h"
#include "cartas.h"
#include "jugador.h"
#include "jugadores.h"
#include "jugada.h"
#include "jugadas.h"
#include "colores.h"
#include "partida.h"


void calcular_jugadas_posibles(tjugadas *pj,tcarta um,tcartas mano)
{
  int i;
	pj->njugadas=0;
	for(i=0;i<mano.nc;i++)
  {
		if(um.fig==mano.cartas[i].fig || um.color==mano.cartas[i].color)
		{
		  pj->jugs[pj->njugadas].carta=mano.cartas[i];
		  pj->jugs[pj->njugadas].pos=i;
		  pj->njugadas++;
		}
	}
}
void mostrar_jugadas(tjugadas pj)
{
	int i; 
	for(i=0;i<pj.njugadas;i++)
	{
		printf("%d(|",i);
		mostrar_carta(pj.jugs[i].carta);
		printf("|) ");
	}
}
